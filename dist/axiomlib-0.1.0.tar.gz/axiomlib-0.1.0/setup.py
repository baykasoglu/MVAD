from setuptools import find_packages, setup

setup(
    name='axiomlib',
    packages=find_packages(include=['axiomlib']),
    version='0.1.0',
    description='Axiomatic Design Library',
    author='FilizSenyuzluler',
)